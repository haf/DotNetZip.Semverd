﻿{
AlertPair=DAL1441 / FLG892
DateTimeOfAlert=11/02/2009 13:08:45
Facility=A80
Sensor=ATL
ConfigName=A80_ATL
EntryCreator=Auto Generated
DateTimeOfEntry=2009-12-16 18:11:08
LogAction=Alert List --> AutoReported
LogMessage=Auto package creation
}